<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);

//$cllr = $_POST["cllr_no"];
$email = $_POST["email"];
$tpcs = $_POST["tpcs"];
$cllr = 0;
if ($r = mysqli_query($link, "SELECT CLLR_NO from APP_CLLR where CLLR_EMAIL='$email'")){
	while ($row=$r->fetch_assoc()){
		$cllr = $row["CLLR_NO"];
	}
}

foreach ($tpcs as $tpc) {
	if ($r = mysqli_query($link, "SELECT * from APP_QUAL where CLLR_NO='$cllr' and TPC_NO='$tpc'")){
		if($r->num_rows == 0){
			if ($r = mysqli_query($link, "INSERT into APP_QUAL (CLLR_NO,TPC_NO) values ('$cllr','$tpc')")){
				echo 1."<br/>";	
			}
		} else {
			echo -1."<br/>";
		}
	}
}

mysqli_close($link);
?>