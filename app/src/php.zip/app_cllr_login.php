<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$email = $_POST["email"];
$pw = $_POST["pw"];
$output=array();
/* comment */
if ($r = mysqli_query($link, "SELECT CLLR_NO from APP_CLLR where CLLR_EMAIL = '$email' and CLLR_PW = '$pw'")) {
	if($r->num_rows == 1){
		$row=$r->fetch_assoc();
		echo $row["CLLR_NO"];
	} else {
		echo -1;
	}
}

mysqli_close($link);
?>