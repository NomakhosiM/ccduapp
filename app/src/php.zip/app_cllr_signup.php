<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$uname = $_POST["uname"];
$pw = $_POST["pw"];
if ($r = mysqli_query($link, "SELECT CLLR_NO from APP_CLLR where CLLR_EMAIL='$uname'")){
	if($r->num_rows > 0){
		echo -1;
	} else {
		if ($r = mysqli_query($link, "INSERT into APP_CLLR (CLLR_EMAIL,CLLR_PW) values ('$uname','$pw')")){
			if($t = mysqli_query($link, "SELECT CLLR_NO from APP_CLLR where CLLR_EMAIL='$uname'");	
		}
	}
}

mysqli_close($link);
?>