<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$uname = $_POST["uname"];
$pw = $_POST["pw"];
$output=array();
/* comment */
if ($r = mysqli_query($link, "SELECT CLT_NO from APP_CLT where CLT_UNAME = '$uname' and CLT_PW = '$pw'")) {
	if($r->num_rows == 1){
		$row=$r->fetch_assoc();
		echo $row["CLT_NO"];
	} else {
		echo -1;
	}
}

mysqli_close($link);
?>