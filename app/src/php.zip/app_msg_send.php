<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$clt = $_POST["clt_no"];
$cllr = $_POST["cllr_no"];
$sender = $_POST["sender"];
$msg = $_POST["msg"];
if (empty($msg)) {
	echo -1;
} else {
	echo $msg;
	$qry = "INSERT INTO APP_MSG(CLT_NO,CLLR_NO,SENDER,TIME,TEXT) VALUES ('$clt','$cllr','$sender',CURRENT_TIMESTAMP,'$msg')";
	if ($r = mysqli_query($link, $qry)){
		echo 1;	
	} else {
		echo -1;
	}
}
mysqli_close($link);
?>