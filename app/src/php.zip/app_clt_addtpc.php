<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);

//$clt = $_POST["clt_no"];
$uname = $_POST["uname"];
$tpc = $_POST["tpc_no"];
$clt = 0;
if ($r = mysqli_query($link, "SELECT CLT_NO from APP_CLT where CLT_UNAME='$uname'")){
	while ($row=$r->fetch_assoc()){
		$clt = $row["CLT_NO"];
	}
}

if ($r = mysqli_query($link, "SELECT * from APP_PRB where CLT_NO='$clt' and TPC_NO='$tpc'")){
	if($r->num_rows == 0){
		if ($r = mysqli_query($link, "INSERT into APP_PRB (CLT_NO,TPC_NO) values ('$clt','$tpc')")){
			echo 1;	
		}
	} else {
		echo -1;
	}
}

mysqli_close($link);
?>