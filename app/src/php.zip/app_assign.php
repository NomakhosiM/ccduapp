<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);

$clt_no = $_POST["clt_no"];
/*Build the query*/
$qry = "SELECT CLLR_NO from APP_CLLR where CLLR_NO >=1";
if ($r = mysqli_query($link, "SELECT TPC_NO from APP_PRB where CLT_NO='$clt_no'")){
	while ($row=$r->fetch_assoc()){
		$x = $row["TPC_NO"];
		$qry.=" and CLLR_NO in (SELECT CLLR_NO from APP_QUAL where TPC_NO='$x')";
	}
}
/*Get the list*/
$list=array();
if ($r = mysqli_query($link, $qry)){
	while ($row=$r->fetch_assoc()){
		$x=$row["CLLR_NO"];
		if ($s = mysqli_query($link, "SELECT count(CLLR_NO) as NUM_CLT from APP_CLT where CLLR_NO = '$x'")){
			$y=$s->fetch_assoc()["NUM_CLT"];
			$list[$x] = $y;
		}
	}
}
/*Assign the client*/
if(count($list)>0){
	asort($list);
	$rec = array_keys($list)[0];
	$update = "UPDATE APP_CLT set CLLR_NO = '$rec' where CLT_NO = '$clt_no'";
	if (mysqli_query($link, $update)){
		echo $rec;
	}
} else {
	echo -1;
}

mysqli_close($link);
?>