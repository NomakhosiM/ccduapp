<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$cllr_no = $_POST["cllr_no"];
$output=array();

if ($r = mysqli_query($link, "SELECT CLT_NO, from APP_CLT where CLLR_NO='$cllr_no'")) {
	while ($row=$r->fetch_assoc()){
		$output[]=$row;
	}
}

mysqli_close($link);
echo json_encode($output);
?>