<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$clt_no = $_POST["clt_no"];
$output=array();
$cllr_no = "";
if ($r = mysqli_query($link, "SELECT CLLR_NO from APP_CLT where CLT_NO = '$clt_no'")) {
	while ($row=$r->fetch_assoc()){
		$cllr_no=$row["CLLR_NO"];
	}
}
if ($r = mysqli_query($link, "SELECT CLLR_NO,CLLR_FNAME,CLLR_LNAME,CLLR_EMAIL from APP_CLLR where CLLR_NO = '$cllr_no'")) {
	while ($row=$r->fetch_assoc()){
		$output[]=$row;
	}
}

mysqli_close($link);
echo json_encode($output);
?>