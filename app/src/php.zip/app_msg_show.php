<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$clt = $_POST["clt_no"];
$cllr = $_POST["cllr_no"];
$output=array();

if ($r = mysqli_query($link, "SELECT TEXT,SENDER,TIME from APP_MSG where CLLR_NO='$cllr' and CLT_NO='$clt'")) {
	while ($row=$r->fetch_assoc()){
		$output[]=$row;
	}
}

echo json_encode($output);
mysqli_close($link);
?>