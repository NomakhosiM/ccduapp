<?php
$username = "s2500339";
$password = "s2500339";
$database = "d2500339";
$link = mysqli_connect("127.0.0.1", $username, $password, $database);
$uname = $_POST["uname"];
$pw = $_POST["pw"];

if ($r = mysqli_query($link, "SELECT CLT_NO from APP_CLT where CLT_UNAME='$uname'")){
	if($r->num_rows > 0){
		echo "Username is taken.";
	} else {
		if ($r = mysqli_query($link, "INSERT into APP_CLT (CLT_UNAME,CLT_PW) values ('$uname','$pw')")){
			echo "Signup successful";	
		}
	}
}

mysqli_close($link);
?>