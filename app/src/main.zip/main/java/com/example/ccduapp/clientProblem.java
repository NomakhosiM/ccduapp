package com.example.ccduapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class clientProblem extends AppCompatActivity {

    OkHttpClient client;
    String clientURL = "https://lamp.ms.wits.ac.za/home/s2500339/app_clt_addtpc.php";
    private Switch mentalH1;
    private Switch domesticV1;
    private Switch careerB1;
    private TextView respondText;
    private EditText reEnterUname;
    private Button clientToLogIn;

    public clientProblem() {
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_problem);

        client = new OkHttpClient();
        respondText = (TextView) findViewById(R.id.respondText);
        mentalH1 = (Switch) findViewById(R.id.mentalH1);
        domesticV1 = (Switch) findViewById(R.id.domesticV1);
        careerB1 = (Switch) findViewById(R.id.careerB1);
        reEnterUname = (EditText) findViewById(R.id.reEnterUname);
        clientToLogIn = (Button) findViewById(R.id.clientToLogIn);

        clientToLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String URL = "https://lamp.ms.wits.ac.za/home/s2500339/app_clt_addtpc.php";
                // if switch on, then:
                String mentalH = mentalH1.getText().toString();
                String domesticV = domesticV1.getText().toString();
                String careerB = careerB1.getText().toString();
                String Uname = reEnterUname.getText().toString();
                openMainActivity();


                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        RequestBody postClientLogIn = new FormBody.Builder()
                                // if switch is on; add:
                                .add("tpc", mentalH)
                                .add("tpc", domesticV)
                                .add("tpc", careerB)
                                .add("clt_no", Uname)
                                .build();
                        Request request = new Request.Builder()
                                .url(URL)
                                .post(postClientLogIn)
                                .build();

                        OkHttpClient client = new OkHttpClient();
                        client.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                                final String responseData = response.body().string();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        respondText.setText(responseData);
                                    }
                                });
                            }
                        });
                    }
                }).start();
            }
        });
    }
        private void openMainActivity() {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

