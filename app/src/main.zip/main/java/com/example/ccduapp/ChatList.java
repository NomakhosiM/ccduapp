package com.example.ccduapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class ChatList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_list);
        RecyclerView client = findViewById(R.id.client);

        //new HttpAsyncTask().execute("http://lamp.ms.wits.ac.za/home/s2500339/app_cllr_clts.php?cllr_no=cllr_no");

        ArrayList<ClientInfo> clientInfoArrayList = new ArrayList<>();
        clientInfoArrayList.add(new ClientInfo("Mixo", "Career based, Mental health", R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Mandy", "Domestic", R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Mini", "Mental health", R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Mouse", "Mental health, Domestic",  R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Kamo", "Career based", R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Kele", "Domestic", R.drawable.ic_launcher_foreground));
        clientInfoArrayList.add(new ClientInfo("Kat", "Mental health", R.drawable.ic_launcher_foreground));
        ClientAdapter clientAdapter = new ClientAdapter(clientInfoArrayList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        client.setLayoutManager(linearLayoutManager);
        client.setAdapter(clientAdapter);
    }
    public void onClick(View view){ goToChat();}
    public void goToChat(){
        Intent intent = new Intent(ChatList.this,ChatWindow.class);
        startActivity(intent);
    }
}
